function love.conf(t)
    t.window.width = 850
    t.window.height = 700  
    --t.window.fullscreen = true  
    t.window.icon = "img/bigger.jpg"
    t.window.title = "Nigga Quest" 
end